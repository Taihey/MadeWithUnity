using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FieldProperty13 : MonoBehaviour
{
    public GameObject Player, Spring;
    public float lifeDecay = 0f;
    Player playerscript;
    float timer = 0f;
    int[] iarr = new int[2] {0,0};

    void Build(float startpos, float endpos,  float timespan, float span, int ind)
    {
        if (timer > iarr[ind] * timespan && startpos + iarr[ind] *span < endpos)
        {
            GameObject spring = Instantiate(Spring);
            spring.transform.position = new Vector3(40, -5, startpos + (iarr[ind] * span));
            GameObject spring2 = Instantiate(Spring);
            spring2.transform.position = new Vector3(-80, -5, startpos + (iarr[ind] * span));
            iarr[ind]++;
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        playerscript = Player.GetComponent<Player>();
        playerscript.courseNum = 13;
    }

    // Update is called once per frame
    void Update()
    {
        playerscript.HP -= lifeDecay * Time.deltaTime;

        timer += Time.deltaTime;
        Build(10300, 15000, 0.2f, 500, 0);
        Build(15300, 20000, 0.2f, 200, 1);
    }
}
