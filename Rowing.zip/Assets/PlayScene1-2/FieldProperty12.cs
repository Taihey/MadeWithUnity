using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FieldProperty12 : MonoBehaviour
{
    public GameObject Player;
    public float lifeDecay = 3f;
    Player playerscript;
    // Start is called before the first frame update
    void Start()
    {
        playerscript = Player.GetComponent<Player>();
        playerscript.courseNum = 12;
    }

    // Update is called once per frame
    void Update()
    {
        playerscript.HP -= lifeDecay * Time.deltaTime;
    }
}
