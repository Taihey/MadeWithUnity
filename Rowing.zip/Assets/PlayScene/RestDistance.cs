using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class RestDistance : MonoBehaviour
{
    float bestRecord;

    public GameObject Player;
    GameObject finish, exitButton, mask, yourTime, score;
    TextMeshProUGUI distanceText, scoreText, finishText, yourTimeText;

    Player playerscript;
    Minimap mapscript;
    Timer timer;
    ChasePlayer chasePlayer;
    public float restDistance = 2000f;
    float stayTime = 0f;
    bool finished = false;

    [Serializable]
    //Ghost�̃f�[�^��Json�ɕϊ����邽�߂̃N���X
    private class GhostData
    {
        public float[] recTime;
        public int[] recEvent;
    }

    // Start is called before the first frame update
    void Start()
    {
        finish = GameObject.Find("Finish");
        exitButton = GameObject.Find("ExitButton");
        mask = GameObject.Find("Mask");
        yourTime = GameObject.Find("YourTime(TMP)");
        score = GameObject.Find("ShowScore(TMP)");
        chasePlayer = GameObject.Find("Main Camera").GetComponent<ChasePlayer>();

        finish.SetActive(false);
        mask.SetActive(false);
        yourTime.SetActive(false);
        score.SetActive(false);

        distanceText = GetComponent<TextMeshProUGUI>();
        scoreText = score.GetComponent<TextMeshProUGUI>();
        finishText = finish.GetComponent<TextMeshProUGUI>();
        yourTimeText = yourTime.GetComponent<TextMeshProUGUI>();

        playerscript = Player.GetComponent<Player>();
        mapscript = GameObject.Find("minimap").GetComponent<Minimap>();
        timer = GameObject.Find("Timer").GetComponent<Timer>();

        string keyName = "BestRecord";
        switch (playerscript.courseNum)
        {
            case 1:
                keyName = "BestRecord";
                break;
            case 12:
                keyName = "BestRecord12";
                break;
            case 13:
                keyName = "BestRecord13";
                break;
            case 2:
                keyName = "BestRecord2";
                break;
            case 22:
                keyName = "BestRecord22";
                break;
            case 23:
                keyName = "BestRecord23";
                break;
            case 3:
                keyName = "BestRecord3";
                break;
            case 32:
                keyName = "BestRecord32";
                break;
            case 33:
                keyName = "BestRecord33";
                break;
        }
        bestRecord = PlayerPrefs.GetFloat(keyName, 600f);
    }

    // Update is called once per frame
    void Update()
    {
        if (playerscript.OnRace)
        {
            restDistance = mapscript.goalpos / 10 - (Player.transform.position.z - mapscript.startpos) / 10;
        }

        if (restDistance < 0)
        {
            restDistance = 0;
            finish.SetActive(true);
            exitButton.SetActive(false);

            int min = (int)timer.countTime / 60;
            float sec = timer.countTime - min * 60;
            scoreText.text = string.Format("{0:00}:{1:00.00}", min, sec);

            if (timer.countTime < bestRecord)
            {
                if (chasePlayer.vsGhost) finishText.text = "Win!";
                yourTimeText.text = "New Record!";
                GhostData ghostData = new GhostData();
                ghostData.recTime = timer.recTime;
                ghostData.recEvent = timer.recEvent;
                string ghostJson = JsonUtility.ToJson(ghostData, false);

                string keyName = "BestRecord", keyName2 = "GhostJson";
                switch (playerscript.courseNum)
                {
                    case 1:
                        keyName = "BestRecord";
                        keyName2 = "GhostJson";
                        break;
                    case 12:
                        keyName = "BestRecord12";
                        keyName2 = "GhostJson12";
                        break;
                    case 13:
                        keyName = "BestRecord13";
                        keyName2 = "GhostJson13";
                        break;
                    case 2:
                        keyName = "BestRecord2";
                        keyName2 = "GhostJson2";
                        break;
                    case 22:
                        keyName = "BestRecord22";
                        keyName2 = "GhostJson22";
                        break;
                    case 23:
                        keyName = "BestRecord23";
                        keyName2 = "GhostJson23";
                        break;
                    case 3:
                        keyName = "BestRecord3";
                        keyName2 = "GhostJson3";
                        break;
                    case 32:
                        keyName = "BestRecord32";
                        keyName2 = "GhostJson32";
                        break;
                    case 33:
                        keyName = "BestRecord33";
                        keyName2 = "GhostJson33";
                        break;
                }
                PlayerPrefs.SetFloat(keyName, timer.countTime);
                PlayerPrefs.SetString(keyName2, ghostJson);
            }
        }

        distanceText.text = string.Format("{0:0}m", restDistance);

        if (restDistance == 0)
        {
            stayTime += Time.deltaTime;

            if (stayTime > 2f)
            {
                if (!finished)
                {
                    if (timer.countTime < bestRecord) chasePlayer.PlaySE("BestRecord");
                    else chasePlayer.PlaySE("Finish");

                    finished = true;
                }

                mask.SetActive(true);
                yourTime.SetActive(true);
                score.SetActive(true);
            }

            if (stayTime > 5f)
            {
                SceneManager.LoadScene("CourseSelect");
            }
        }
    }
}
