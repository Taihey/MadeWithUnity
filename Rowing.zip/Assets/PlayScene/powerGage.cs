using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class powerGage : MonoBehaviour
{
    private Image materColor;
    private RectTransform materShape;
    private float powerMax;
    private float power;
    private float width;
    const float posY = 350;
    const float posX = -350;     //���[�^�[�̍��[
    private byte r = 0, g = 255, b = 100;

    //player�̃X�N���v�g��HP��ǂݍ���
    public GameObject player;
    Player plrScript;

    // Start is called before the first frame update
    void Start()
    {
        materColor = GetComponent<Image>();
        materShape = GetComponent<RectTransform>();
        materColor.color = new Color32(r, g, b, 255);

        //player = GameObject.Find("Player");
        plrScript = player.GetComponent<Player>();
        powerMax = plrScript.HPMax;

        materShape.anchoredPosition = new Vector3(posX + 700/2, posY, 0);
    }

    // Update is called once per frame
    void Update()
    {
        power = plrScript.powerGage;
        r = (byte)(255 * (1 - power / powerMax));
        g = (byte)(255 * power / powerMax);
        b = (byte)(100 * power / powerMax);
        materColor.color = new Color32(r, g, b, 255);

        width = 700 * (power / powerMax);
        materShape.anchoredPosition = new Vector3(posX + width / 2, posY, 0);
        materShape.sizeDelta = new Vector2(width, 30);
    }
}
