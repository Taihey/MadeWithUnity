using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class ChasePlayer : MonoBehaviour
{
    public AudioClip[] SEs;
    AudioSource audioSE;

    public GameObject player;
    private Transform plrTrans;
    public int num = 1;            //?J?????????u????????
    public bool vsGhost = false;

    Vector3 frontPos = new Vector3(0, 7, -50);
    Vector3 backPos = new Vector3(0, 7, 50);
    Vector3 rightPos = new Vector3(40, 7, 3);
    Vector3 leftPos = new Vector3(-40, 7, 3);
    Vector3 abavePos = new Vector3(0, 85, -20);

    public void PlaySE(string se)
    {
        switch(se)
        {
            case "Start":
                audioSE.PlayOneShot(SEs[0]);
                break;
            case "Finish":
                audioSE.PlayOneShot(SEs[1]);
                break;
            case "BestRecord":
                audioSE.PlayOneShot(SEs[2]);
                break;
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        audioSE = GetComponent<AudioSource>();

        //player = GameObject.Find("Player");
        plrTrans = player.GetComponent<Transform>();
        transform.position = new Vector3(0, 1, -10);
    }

    // Update is called once per frame
    void Update()
    {
        if (vsGhost)
        {
            leftPos = new Vector3(-80, 7, 0);
            abavePos = new Vector3(-20, 150, -30);
        }

        Vector3 plrPos = plrTrans.position;
        //????
        if (num == 1)
        {
            transform.eulerAngles = new Vector3(10, 0, 0);
            transform.position = plrPos + frontPos;
        }
        //????
        else if (num == 3)
        {
            transform.eulerAngles = new Vector3(10, -180, 0);
            transform.position = plrPos + backPos;
        }
        //?E
        else if (num == 2)
        {
            transform.eulerAngles = new Vector3(10, -90, 0);
            transform.position = plrPos + rightPos;
        }
        //??
        else if (num == 4)
        {
            transform.eulerAngles = new Vector3(0, 90, 0);
            transform.position = plrPos + leftPos;
        }
        else if (num == 5)
        {
            transform.eulerAngles = new Vector3(70, 0, 0);
            transform.position = plrPos + abavePos;
        }
        
    }
}
