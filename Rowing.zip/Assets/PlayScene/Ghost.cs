using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;

public class Ghost : MonoBehaviour
{
    //public int courseNum = 1;

    public float driveForce;
    private float force;
    public float HP = 100f, powerGage = 100f;
    public float HPMax = 100f, powerGageMax = 100f;
    private Rigidbody plrRigid;
    private Animator plrAnime;
    AudioSource ghostAudio;
    public bool OnRace = false;
    public bool Dead = false;
    public bool startDrive = false, duringDrive = false, onClicked = false;

    public GameObject player, ghost;
    Player playerscript;
    Minimap mapscript;
    RestDistance distscript;
    Timer timer;
    ChasePlayer chasePlayer;

    [Serializable]
    private class GhostData
    {
        public float[] recTime;
        public int[] recEvent;
    }
    string ghostJson;
    GhostData ghostData;
    public int index = 0, pow = 1;
    float drivetime = 0f;


    // Start is called before the first frame update
    void Start()
    {
        //Application.targetFrameRate = 60;

        plrRigid = GetComponent<Rigidbody>();
        plrAnime = GetComponent<Animator>();
        ghostAudio = GetComponent<AudioSource>();

        playerscript = player.GetComponent<Player>();
        mapscript = GameObject.Find("minimap").GetComponent<Minimap>();
        distscript = GameObject.Find("RestDistance").GetComponent<RestDistance>();
        timer = GameObject.Find("Timer").GetComponent<Timer>();
        chasePlayer = GameObject.Find("Main Camera").GetComponent<ChasePlayer>();

        transform.position = new Vector3(-40, 0.7f, mapscript.startpos);

        string keyName = "GhostJson";
        switch (playerscript.courseNum)
        {
            case 1:
                keyName = "GhostJson";
                break;
            case 12:
                keyName = "GhostJson12";
                break;
            case 13:
                keyName = "GhostJson13";
                break;
            case 2:
                keyName = "GhostJson2";
                break;
            case 22:
                keyName = "GhostJson22";
                break;
            case 23:
                keyName = "GhostJson23";
                break;
            case 3:
                keyName = "GhostJson3";
                break;
            case 32:
                keyName = "GhostJson32";
                break;
            case 33:
                keyName = "GhostJson33";
                break;
        }
        ghostJson = PlayerPrefs.GetString(keyName, "null");

        UnityEngine.Debug.Log(ghostJson);
        if (ghostJson == "null")
        {
            chasePlayer.vsGhost = false;
            ghost.SetActive(false);
        }
        else
        {
            chasePlayer.vsGhost = true;
            ghost.SetActive(true);
            ghostData = JsonUtility.FromJson<GhostData>(ghostJson);
            UnityEngine.Debug.Log(ghostData.recEvent.Length);
        }
    }

    
    private void FixedUpdate()
    {
        if (duringDrive)
        {
            Vector3 drive = new Vector3(0, 0, 1);
            plrRigid.AddForce(drive * force, ForceMode.Force);
        }
    }

    void Replay()
    {
        if (timer.countTime > ghostData.recTime[index] && ghostData.recEvent[index] != 0)
        {
            if (ghostData.recEvent[index] == -1)
            {
                startDrive = true;
                duringDrive = true;
                onClicked = true;

                OnRace = true;
            }
            else
            {
                pow = ghostData.recEvent[index];
            }
            index++;

            //�������Ԃ�2�ȏ�C�x���g���������ꍇ�p
            Replay();
        }
    }
    // Update is called once per frame
    void Update()
    {
        //�L�^�ʂ�ɍs������
        Replay();

        if (!OnRace && distscript.restDistance > 0)
        {
            transform.position = new Vector3(-40, 0.7f, mapscript.startpos);
        }

        /*if (distscript.restDistance == 0)
        {
            OnRace = false;
        }*/

        if (!duringDrive)
        {
            powerGage += 0.5f * Time.deltaTime;
            HP += 3 * Time.deltaTime;
            if (powerGage > powerGageMax) powerGage = powerGageMax;
            if (HP > HPMax) HP = HPMax;
        }

        if (startDrive)
        {
            if (onClicked)
            {
                plrAnime.SetBool("drive", false);
                onClicked = false;
            }
            else
            {
                startDrive = false;
                plrAnime.SetBool("drive", true);
            }
        }

        //0.6s�ԗ͂�����������
        if (duringDrive)
        {
            drivetime += Time.deltaTime;
            powerGage -= 0.2f * pow * pow * Time.deltaTime;
            HP -= (4 + 0.7f * pow) * Time.deltaTime;
            if (powerGage < 0) powerGage = 0;
            if (HP < 0) HP = 0;
            if (drivetime > 0.7)
            {
                drivetime = 0f;
                ghostAudio.Play();
                duringDrive = false;
            }
        }


        //HP��0�ɂȂ�Ɠ_�ŁA������x�񕜂���Ɩ߂�
        if (!Dead)
        {
            force = driveForce * pow;
            if (HP == 0 || powerGage == 0)
            {
                Dead = true;
            }
        }
        else if (Dead)
        {
            force = driveForce;
            if (HP / HPMax > 0.1 && powerGage > 0)
            {
                Dead = false;
            }
        }
    }
}
