using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Timer : MonoBehaviour
{
    public GameObject player;
    Player plrScript;
    private TextMeshProUGUI timer;
    public float countTime = 0;

    ChasePlayer mainCamera;
    bool init = false;

    //save
    public float[] recTime = new float[36000];
    public int[] recEvent = new int[36000];
    int index = 0;

    // Start is called before the first frame update
    void Start()
    {
        //player = GameObject.Find("Player");
        plrScript = player.GetComponent<Player>();

        mainCamera = GameObject.Find("Main Camera").GetComponent<ChasePlayer>();

        timer = GetComponent<TextMeshProUGUI>();
    }

    // Update is called once per frame
    void Update()
    {
        if (plrScript.OnRace)
        {
            if (!init)
            {
                mainCamera.PlaySE("Start");
                init = true;
            }
            countTime += Time.deltaTime;
        }
        int min = (int)countTime / 60;
        float sec = countTime - min * 60;
        timer.text = string.Format("{0:00}:{1:00.##}", min, sec);    
    }

    //powerup = 1~10, drive = -1
    public void save(int num)
    {
        recTime[index] = countTime;
        recEvent[index] = num;
        index++;
    }
}
