using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class ChengeCameraPos : MonoBehaviour
{
    GameObject MainCamera;
    ChasePlayer camerascript;

    // Start is called before the first frame update
    void Start()
    {
        MainCamera = GameObject.Find("Main Camera");
        camerascript = MainCamera.GetComponent<ChasePlayer>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.C)) OnClick();
    }

    public void OnClick()
    {
        camerascript.num++;
        if (camerascript.num > 5) camerascript.num = 1;
    }
}
