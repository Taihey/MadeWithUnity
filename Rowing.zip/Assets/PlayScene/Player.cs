using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    //���̐����ŃV�[���𔻒肷��
    public int courseNum = 1;

    public float driveForce;
    private float force;
    public float HP = 100f, powerGage = 100f;
    public float HPMax = 100f, powerGageMax = 100f;
    private Rigidbody plrRigid;
    private Animator plrAnime;
    AudioSource plrAudio;
    public bool OnRace = false;
    public bool Dead = false;
    public bool startDrive = false, duringDrive = false, onClicked = false;

    Minimap mapscript;
    RestDistance distscript;
    UpDownPower powscript;

    // Start is called before the first frame update
    void Start()
    {
        Application.targetFrameRate = 60;

        plrRigid = GetComponent<Rigidbody>();
        plrAnime = GetComponent<Animator>();
        plrAudio = GetComponent<AudioSource>();

        mapscript = GameObject.Find("minimap").GetComponent<Minimap>();
        distscript = GameObject.Find("RestDistance").GetComponent<RestDistance>();
        powscript = GameObject.Find("UpPower").GetComponent<UpDownPower>();

        transform.position = new Vector3(0, 0.7f, mapscript.startpos);
    }

    float drivetime = 0f;
    private void FixedUpdate()
    {
        if (duringDrive)
        {
            Vector3 drive = new Vector3(0, 0, 1);
            plrRigid.AddForce(drive * force, ForceMode.Force);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (!OnRace && distscript.restDistance > 0)
        {
            transform.position = new Vector3(0, 0.7f, mapscript.startpos);
        }

        if (distscript.restDistance == 0)
        {
            OnRace = false;
        }

        if (!duringDrive)
        {
            powerGage += 0.5f * Time.deltaTime;
            HP += 3 * Time.deltaTime;
            if (powerGage > powerGageMax) powerGage = powerGageMax;
            if (HP > HPMax) HP = HPMax;
        }

        if (startDrive)
        {
            if (onClicked)
            {
                plrAnime.SetBool("drive", false);
                onClicked = false;
            }
            else
            {
                startDrive = false;
                plrAnime.SetBool("drive", true);
            }
        }

        //0.6s�ԗ͂�����������
        if (duringDrive)
        {
            drivetime += Time.deltaTime;
            powerGage -= 0.2f * powscript.pow * powscript.pow* Time.deltaTime;
            HP -= (4 + 0.7f * powscript.pow) * Time.deltaTime;
            if (powerGage < 0) powerGage = 0;
            if (HP < 0) HP = 0;
            if (drivetime > 0.7)
            {
                drivetime = 0f;
                plrAudio.Play();
                duringDrive = false;
            }
        }

        //HP��0�ɂȂ�Ɠ_�ŁA������x�񕜂���Ɩ߂�
        if (!Dead)
        {
            force = driveForce * powscript.pow;
            if (HP == 0 || powerGage == 0)
            {
                Dead = true;
            }
        } else if (Dead)
        {
            force = driveForce;
            if (HP/HPMax > 0.1 && powerGage > 0)
            {
                Dead = false;
            }
        }
    }
}
