using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FieldBuilder : MonoBehaviour
{
    public GameObject Building, Building2, StartPos, Bui, Pole, Gate, Buzzer;
    public GameObject Water;
    Minimap mapscript;
    // Start is called before the first frame update
    void Start()
    {
        mapscript = GameObject.Find("minimap").GetComponent<Minimap>();

        Buzzer.transform.position = new Vector3(60, 9, mapscript.startpos + mapscript.goalpos);

        GameObject building  = Instantiate(Building);
        building.transform.position = new Vector3(-20, 0, mapscript.startpos - 140);
        GameObject buildingG = Instantiate(Building);
        buildingG.transform.position = new Vector3(0, 0, mapscript.startpos + mapscript.goalpos + 1800);

        GameObject startPos = Instantiate(StartPos);
        startPos.transform.position = new Vector3(0, 1, mapscript.startpos - 25);
        GameObject startPos2 = Instantiate(StartPos);
        startPos2.transform.position = new Vector3(-40, 1, mapscript.startpos - 25);

        for (int i = 0; i < 3000/100; i++)
        {
            GameObject building2 = Instantiate(Building2);
            building2.transform.position = new Vector3(150, 0, mapscript.startpos + 120 * i);
            GameObject building2l = Instantiate(Building2);
            building2l.transform.position = new Vector3(-160, 0, mapscript.startpos + 120 * i);
            building2.transform.eulerAngles = new Vector3(0, 180, 0);
        }

        for (int i = 0; i < mapscript.goalpos/50; i++)
        {
            GameObject lBui = Instantiate(Bui);
            lBui.transform.position = new Vector3(-20, 0, mapscript.startpos + 50 * i);
            if (i > 0)
            {
                GameObject llBui = Instantiate(Bui);
                llBui.transform.position = new Vector3(-60, 0, mapscript.startpos + 50 * i);
                GameObject rBui = Instantiate(Bui);
                rBui.transform.position = new Vector3(20, 0, mapscript.startpos + 50 * i);
            }
        }

        for (int i = 0; i < mapscript.goalpos/1000; i++)
        {
            GameObject lPole = Instantiate(Pole);
            lPole.transform.position = new Vector3(-20, 8, mapscript.startpos + 1000 * i);
            if (i > 0)
            {
                GameObject llPole = Instantiate(Pole);
                llPole.transform.position = new Vector3(-60, 8, mapscript.startpos + 1000 * i);
                GameObject rPole = Instantiate(Pole);
                rPole.transform.position = new Vector3(20, 8, mapscript.startpos + 1000 * i);
            }
        }

        for (int i = 0; i <= 4; i++)
        {
            GameObject Gateway = Instantiate(Gate);
            Gateway.transform.position = new Vector3(-20, 0, mapscript.startpos + (mapscript.goalpos / 4) * i);
        }

        for (int i = 0; i < mapscript.goalpos/200 + 10; i++)
        {
            Water.transform.position = new Vector3(0, -3, 200 * i);
            Instantiate(Water);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
