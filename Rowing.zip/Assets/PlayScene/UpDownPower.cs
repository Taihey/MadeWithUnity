using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class UpDownPower : MonoBehaviour
{
    public int pow = 1;
    public GameObject Player;

    TextMeshProUGUI PowerInt;
    Timer timscript;
    Player plrscript;
    // Start is called before the first frame update
    void Start()
    {
        PowerInt = GameObject.Find("PowerINT(TMP)").GetComponent<TextMeshProUGUI>();
        timscript = GameObject.Find("Timer").GetComponent<Timer>();
        plrscript = Player.GetComponent<Player>();
    }

    // Update is called once per frame
    void Update()
    {
        PowerInt.text = string.Format("{0:0}", pow);

        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            Debug.Log("Down");
            OnClickUp();
        }
        if (Input.GetKeyDown(KeyCode.DownArrow)) OnClickDown();
    }

    public void OnClickUp()
    {
        pow++;
        if (pow > 10) pow = 10;
        if (plrscript.OnRace) timscript.save(pow);
    }

    public void OnClickDown()
    {
        pow--;
        if (pow < 1) pow = 1;
        if (plrscript.OnRace) timscript.save(pow);
    }
}
