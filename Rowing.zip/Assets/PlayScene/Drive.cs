using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Drive : MonoBehaviour
{
    public GameObject Player;

    Player playerscript;
    RestDistance distscript;
    Timer timscript;
    UpDownPower powscript;
    // Start is called before the first frame update
    void Start()
    {
        playerscript = Player.GetComponent<Player>();
        distscript = GameObject.Find("RestDistance").GetComponent<RestDistance>();
        timscript = GameObject.Find("Timer").GetComponent<Timer>();
        powscript = GameObject.Find("UpPower").GetComponent<UpDownPower>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.Space)) OnClick();
    }
    public void OnClick()
    {
        //playerscript.HP -= 13f;
        //if (playerscript.HP < 0) playerscript.HP = 0;

        if (distscript.restDistance > 0)
        {
            playerscript.startDrive = true;
            playerscript.duringDrive = true;
            //�����ŕς���ƁA���t���[������ture�ɏ����������Ă��܂�
            //playerscript.plrAnime.SetBool("drive", false);
            playerscript.onClicked = true;

            //�J�n����pow���L�^
            if (!playerscript.OnRace) timscript.save(powscript.pow);
            timscript.save(-1);

            playerscript.OnRace = true;
        }
    }
}
