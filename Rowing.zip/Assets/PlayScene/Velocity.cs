using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Velocity : MonoBehaviour
{
    public GameObject Player;
    private Rigidbody plrRigid;
    private TextMeshProUGUI Vel;

    // Start is called before the first frame update
    void Start()
    {
        plrRigid = Player.GetComponent<Rigidbody>();
        Vel = GetComponent<TextMeshProUGUI>();
    }

    // Update is called once per frame
    void Update()
    {
        Vel.text = string.Format("{0:0}km/h",plrRigid.velocity.z/10 * 3.6);
    }
}
