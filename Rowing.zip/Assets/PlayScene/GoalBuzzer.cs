using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoalBuzzer : MonoBehaviour
{
    public GameObject Player, Ghost;
    AudioSource finishBuzzer;
    bool p = false, g = false;
    // Start is called before the first frame update
    void Start()
    {
        finishBuzzer = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Player.transform.position.z > transform.position.z && !p)
        {
            finishBuzzer.Stop();
            finishBuzzer.Play();
            p = true;
        }
        if (Ghost.transform.position.z > transform.position.z && !g)
        {
            finishBuzzer.Stop();
            finishBuzzer.Play();
           g = true;
        }
    }
}
