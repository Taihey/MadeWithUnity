using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Minimap : MonoBehaviour
{
    Image mapColor;
    byte g = 255, b = 255;
    public GameObject Player;
    Player playerscript;
    public float startpos = 30f, goalpos = 20000f;
    RectTransform MiniPlayer;
    // Start is called before the first frame update
    void Start()
    {
        mapColor = GetComponent<Image>();
        playerscript = Player.GetComponent<Player>();
        startpos = Player.transform.position.z;
        MiniPlayer = GetComponent<RectTransform>();
        MiniPlayer.anchoredPosition = new Vector2(-350, 530);
    }

    // Update is called once per frame
    void Update()
    {
        if (Player.transform.position.z - startpos < goalpos)
        {
            MiniPlayer.anchoredPosition = new Vector2(-350 + 700 * (Player.transform.position.z-startpos) / goalpos, 450);
        }

        if (playerscript.Dead)
        {
            g += 5;
            b += 5;
            mapColor.color = new Color32(255, g, b, 255);
        }
        else
        {
            mapColor.color = new Color32(255, 255, 255, 255);
        }
    }
}
