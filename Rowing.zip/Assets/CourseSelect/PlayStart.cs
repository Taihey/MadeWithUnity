using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class PlayStart : MonoBehaviour
{
    GameObject BR, BR2, BR3;
    TextMeshProUGUI BRtext, BR2text, BR3text;

    bool[] clicked = new bool[9], initbool = new bool[9];
    
    string SetText(string key)
    {
        string text;
        float BRTime = PlayerPrefs.GetFloat(key, 0f);
        int min = (int)BRTime / 60;
        float sec = BRTime - min * 60;
        if (BRTime == 0f) text = "--:--.--";
        else text = string.Format("{0:00}:{1:00.00}", min, sec);

        return text;
    }

    // Start is called before the first frame update
    void Start()
    {
        BR = GameObject.Find("BestRecord");
        BRtext = BR.GetComponent<TextMeshProUGUI>();
        BR2 = GameObject.Find("BestRecord2");
        BR2text = BR2.GetComponent<TextMeshProUGUI>();
        BR3 = GameObject.Find("BestRecord3");
        BR3text = BR3.GetComponent<TextMeshProUGUI>();

        for (int i = 0; i < 9; i++)
        {
            clicked[i] = false;
            initbool[i] = false;
        }
    }

    // Update is called once per frame
    void Update()
    {
    }

    //1��ڂ̃N���b�N�Ń��R�[�h�\���A2��ڂŃX�^�[�g
    public void OnClick()
    {
        BR.SetActive(true);
        BR2.SetActive(false);
        BR3.SetActive(false);

        BRtext.text = SetText("BestRecord");
        
        if (clicked[0]) SceneManager.LoadScene("PlayScene");
        else
        {
            Array.Copy(initbool, clicked, 9);
            clicked[0] = true;
        }
    }
    public void OnClick12()
    {
        BR.SetActive(true);
        BR2.SetActive(false);
        BR3.SetActive(false);

        BRtext.text = SetText("BestReord12");

        if (clicked[1]) SceneManager.LoadScene("PlayScene12");
        else
        {
            Array.Copy(initbool, clicked, 9);
            clicked[1] = true;
        }
    }
    public void OnClick13()
    {
        BR.SetActive(true);
        BR2.SetActive(false);
        BR3.SetActive(false);

        BRtext.text = SetText("BestRecord13");

        if (clicked[2]) SceneManager.LoadScene("PlayScene13");
        else
        {
            Array.Copy(initbool, clicked, 9);
            clicked[2] = true;
        }
    }

    public void OnClick2()
    {
        BR.SetActive(false);
        BR2.SetActive(true);
        BR3.SetActive(false);

        BR2text.text = SetText("BestRecord2");

        if (clicked[3]) SceneManager.LoadScene("PlayScene2");
        else
        {
            Array.Copy(initbool, clicked, 9);
            clicked[3] = true;
        }
    }
    public void OnClick22()
    {
        BR.SetActive(false);
        BR2.SetActive(true);
        BR3.SetActive(false);

        BR2text.text = SetText("BestRecord22");

        if (clicked[4]) SceneManager.LoadScene("PlayScene22");
        else
        {
            Array.Copy(initbool, clicked, 9);
            clicked[4] = true;
        }
    }
    public void OnClick23()
    {
        BR.SetActive(false);
        BR2.SetActive(true);
        BR3.SetActive(false);

        BR2text.text = SetText("BestRecord23");

        if (clicked[5]) SceneManager.LoadScene("PlayScene23");
        else
        {
            Array.Copy(initbool, clicked, 9); ;
            clicked[5] = true;
        }
    }

    public void OnClick3()
    {
        BR.SetActive(false);
        BR2.SetActive(false);
        BR3.SetActive(true);

        BR3text.text = SetText("BestRecord3");

        if (clicked[6]) SceneManager.LoadScene("PlayScene3");
        else
        {
            Array.Copy(initbool, clicked, 9);
            clicked[6] = true;
        }
    }
    public void OnClick32()
    {
        BR.SetActive(false);
        BR2.SetActive(false);
        BR3.SetActive(true);

        BR3text.text = SetText("BestRecord32");

        if (clicked[7]) SceneManager.LoadScene("PlayScene32");
        else
        {
            Array.Copy(initbool, clicked, 9);
            clicked[7] = true;
        }
    }
    public void OnClick33()
    {
        BR.SetActive(false);
        BR2.SetActive(false);
        BR3.SetActive(true);

        BR3text.text = SetText("BestRecord33");

        if (clicked[8]) SceneManager.LoadScene("PlayScene33");
        else
        {
            Array.Copy(initbool, clicked, 9);
            clicked[8] = true;
        }
    }
}
