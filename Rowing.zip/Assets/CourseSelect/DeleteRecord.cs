using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DeleteRecord : MonoBehaviour
{
    GameObject sheet, notion, del, notDel;
    // Start is called before the first frame update
    void Start()
    {
        sheet = GameObject.Find("Sheet");
        sheet.GetComponent<RectTransform>().anchoredPosition = Vector3.zero;
        sheet.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Delete()
    {
        PlayerPrefs.DeleteKey("BestRecord");
        PlayerPrefs.DeleteKey("BestRecord2");
        PlayerPrefs.DeleteKey("BestRecord3");
        PlayerPrefs.DeleteKey("BestRecord12");
        PlayerPrefs.DeleteKey("BestRecord22");
        PlayerPrefs.DeleteKey("BestRecord32");
        PlayerPrefs.DeleteKey("BestRecord13");
        PlayerPrefs.DeleteKey("BestRecord23");
        PlayerPrefs.DeleteKey("BestRecord33");
        PlayerPrefs.DeleteKey("GhostJson");
        PlayerPrefs.DeleteKey("GhostJson2");
        PlayerPrefs.DeleteKey("GhostJson3");
        PlayerPrefs.DeleteKey("GhostJson12");
        PlayerPrefs.DeleteKey("GhostJson22");
        PlayerPrefs.DeleteKey("GhostJson32");
        PlayerPrefs.DeleteKey("GhostJson13");
        PlayerPrefs.DeleteKey("GhostJson23");
        PlayerPrefs.DeleteKey("GhostJson33");
        SceneManager.LoadScene("CourseSelect");
    }

    public void notDelete()
    {
        sheet.SetActive(false);
    }

    public void Configuration()
    {
        sheet.SetActive(true);
    }
}
