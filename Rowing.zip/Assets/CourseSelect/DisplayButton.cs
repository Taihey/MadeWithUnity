using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DisplayButton : MonoBehaviour
{
    GameObject Button1_2, Button2_2, Button3_2, BestRecord, BestRecord2, BestRecord3, BRText, BRText2, BRText3;

    bool[] clicked = new bool[3] { false, false, false }, initbool = new bool[3] {false, false, false};
    
    // Start is called before the first frame update
    void Start()
    {
        Button1_2 = GameObject.Find("Button1_2");
        Button2_2 = GameObject.Find("Button2_2");
        Button3_2 = GameObject.Find("Button3_2");
        BestRecord = GameObject.Find("BestRecord");
        BestRecord2 = GameObject.Find("BestRecord2");
        BestRecord3 = GameObject.Find("BestRecord3");
        BRText = GameObject.Find("BRText");
        BRText2 = GameObject.Find("BRText2");
        BRText3 = GameObject.Find("BRText3");

        Button1_2.SetActive(false);
        Button2_2.SetActive(false);
        Button3_2.SetActive(false);
        BestRecord.SetActive(false);
        BestRecord2.SetActive(false);
        BestRecord3.SetActive(false);
        BRText.SetActive(false);
        BRText2.SetActive(false);
        BRText3.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnClick()
    {
        if (!clicked[0])
        {
            Button1_2.SetActive(true);
            BRText.SetActive(true);
            clicked = initbool;
            clicked[0] = true;
        }
        else
        {
            Button1_2.SetActive(false);
            BRText.SetActive(false);
            BestRecord.SetActive(false);
            clicked[0] = false;
        }
        Button2_2.SetActive(false);
        Button3_2.SetActive(false);
        BRText2.SetActive(false);
        BRText3.SetActive(false);
        
        BestRecord2.SetActive(false);
        BestRecord3.SetActive(false);
    }
    public void OnClick2()
    {
        if (!clicked[1])
        {
            Button2_2.SetActive(true);
            BRText2.SetActive(true);
            clicked = initbool;
            clicked[1] = true;
        }
        else
        {
            Button2_2.SetActive(false);
            BRText2.SetActive(false);
            BRText2.SetActive(false);
            clicked[1] = false;
        }
        Button1_2.SetActive(false);
        Button3_2.SetActive(false);
        BRText.SetActive(false);
        BRText3.SetActive(false);

        BRText.SetActive(false);
        BRText3.SetActive(false);
    }

    public void OnClick3()
    {
        if (!clicked[2])
        {
            Button3_2.SetActive(true);
            BRText3.SetActive(true);
            clicked = initbool;
            clicked[2] = true;
        }
        else
        {
            Button3_2.SetActive(false);
            BRText3.SetActive(false);
            BRText3.SetActive(false);
            clicked[2] = false;
        }
        Button1_2.SetActive(false);
        Button2_2.SetActive(false);
        BRText.SetActive(false);
        BRText2.SetActive(false);

        BRText.SetActive(false);
        BRText2.SetActive(false);
    }
}
