using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FieldProperty33 : MonoBehaviour
{
    public GameObject Player, Ghost, Star;
    public float lifeDecay = -3f, powerDecay = -3f;
    Player playerscript;
    Ghost ghost;

    float[] Timer = new float[2] {0, 0};
    bool flag = true;

    void StarDust(float start, float end, float delta, float del)
    {
        for (int i = 0; i < (end - start) / delta; i++)
        {
            /*GameObject star = Instantiate(Star);
            star.transform.position = new Vector3(200, 0, start + delta * i + del);*/

            GameObject star2 = Instantiate(Star);
            star2.transform.position = new Vector3(-1000, 0, start + delta * i + del);
        }
    }
     
    void geneStarDust(float start, float end, float timespan, float delta, int ind)
    {

        if (Timer[ind] > timespan) {
            if (flag)
            {
                StarDust(start, end, delta, 0);
                flag = false;
                Timer[ind] = 0;
            }
            else
            {
                StarDust(start, end, delta, delta / 2);
                flag = true;
                Timer[ind] = 0;
            }
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        playerscript = Player.GetComponent<Player>();
        playerscript.courseNum = 33;
        ghost = Ghost.GetComponent<Ghost>();
    }

    // Update is called once per frame
    void Update()
    {
        playerscript.powerGage -= powerDecay * Time.deltaTime;
        playerscript.HP -= lifeDecay * Time.deltaTime;
        ghost.powerGage -= powerDecay * Time.deltaTime;
        ghost.HP -= lifeDecay * Time.deltaTime;

        //�w�i
        for (int i = 0; i < Timer.Length; i++) {
            Timer[i] += Time.deltaTime;
        }
        geneStarDust(40000, 75000, 2.0f, 300, 0);
        geneStarDust(75000, 130000, 1.3f, 300, 1);
    }
}
