using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FieldProperty3 : MonoBehaviour
{
    public GameObject Player, Ghost;
    public float lifeDecay = -3f, powerDecay = -3f;
    Player playerscript;
    Ghost ghost;
    // Start is called before the first frame update
    void Start()
    {
        playerscript = Player.GetComponent<Player>();
        playerscript.courseNum = 3;
        ghost = Ghost.GetComponent<Ghost>();
    }

    // Update is called once per frame
    void Update()
    {
        playerscript.powerGage -= powerDecay * Time.deltaTime;
        playerscript.HP -= lifeDecay * Time.deltaTime;
        ghost.powerGage -= powerDecay * Time.deltaTime;
        ghost.HP -= lifeDecay * Time.deltaTime;
    }
}
