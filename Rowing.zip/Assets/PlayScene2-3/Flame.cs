using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flame : MonoBehaviour
{
    Rigidbody body;
    // Start is called before the first frame update
    void Start()
    {
        body = GetComponent<Rigidbody>();
        body.velocity = new Vector3(-80, 30, 0);
    }

    // Update is called once per frame
    void Update()
    {
        transform.eulerAngles += new Vector3(-15 * Time.deltaTime, 0, 0);

        if (transform.position.y < -10)
        {
            Destroy(this.gameObject);
        }
    }
}
