using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FieldProperty23 : MonoBehaviour
{
    public GameObject Player, Ghost, Flame;
    public float lifeDecay = 3f;
    Player playerscript;
    Ghost ghost;
    ChasePlayer chasePlayer;

    float timer = 0f;
    int[] iarr = new int[2] { 0, 0 };

    void Build(float startpos, float endpos, float timespan, float span, int ind)
    {
        if (timer > iarr[ind] * timespan && startpos + iarr[ind] * span < endpos)
        {
            GameObject flame = Instantiate(Flame);
            flame.transform.position = new Vector3(220, 0, startpos + (iarr[ind] * span));
            iarr[ind]++;
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        playerscript = Player.GetComponent<Player>();
        playerscript.courseNum = 23;

        ghost = Ghost.GetComponent<Ghost>();

        chasePlayer = GameObject.Find("Main Camera").GetComponent<ChasePlayer>();
    }

    // Update is called once per frame
    void Update()
    {
        playerscript.HP -= lifeDecay * Time.deltaTime;
        if (chasePlayer.vsGhost) ghost.HP -= lifeDecay * Time.deltaTime;

        timer += Time.deltaTime;
        Build(5050, 6000, 2f, 300, 0);
        Build(6000, 7000, 1.5f, 150, 0);
        if (timer > 10f)
        {
            timer = 0;
            iarr = new int[2] { 0, 0 };
        }
    }
}
